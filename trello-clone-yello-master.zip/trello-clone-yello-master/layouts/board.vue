<template>
  <v-app>
    <v-content >
        <!-- content -->
          <nuxt />
    </v-content>
  </v-app>
</template>
