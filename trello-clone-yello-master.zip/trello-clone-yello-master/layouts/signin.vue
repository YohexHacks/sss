<template>
  <v-app>
    <v-main  class="signin-layout">
      <v-container class="fill-height">
        <nuxt />
      </v-container>
    </v-main>
  </v-app>
</template>